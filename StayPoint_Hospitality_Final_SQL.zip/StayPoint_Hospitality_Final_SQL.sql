/* STAYPOINT HOSPITALITY - FINAL SQL PROJECT FILE
Contains Sprint 2 setup/verification, Sprint 3 Basic Analysis,
and Sprint 4 Objective-Based Analysis (4.1 to 4.5).
*/

CREATE DATABASE IF NOT EXISTS hotel_reservation;
USE hotel_reservation;

-- ==================== SPRINT 2: TABLE SETUP ====================

CREATE TABLE IF NOT EXISTS hotels (
    hotel_id VARCHAR(20) PRIMARY KEY,
    hotel_name VARCHAR(100),
    city VARCHAR(50),
    star_rating INT,
    total_rooms INT,
    opened_date DATE
);

CREATE TABLE IF NOT EXISTS guests (
    guest_id VARCHAR(20) PRIMARY KEY,
    guest_name VARCHAR(100),
    city VARCHAR(100),
    guest_type VARCHAR(50),
    preferred_room_type VARCHAR(50),
    loyalty_tier VARCHAR(50),
    account_since DATE
);

CREATE TABLE IF NOT EXISTS rooms (
    room_id VARCHAR(20) PRIMARY KEY,
    hotel_id VARCHAR(20),
    room_type VARCHAR(50),
    floor_number INT,
    max_occupancy INT,
    price_per_night DECIMAL(10,2),
    is_active INT,
    FOREIGN KEY (hotel_id) REFERENCES hotels(hotel_id)
);

CREATE TABLE IF NOT EXISTS bookings (
    booking_id VARCHAR(20) PRIMARY KEY,
    guest_id VARCHAR(20),
    hotel_id VARCHAR(20),
    booking_date DATE,
    room_type_requested VARCHAR(50),
    booking_channel VARCHAR(30),
    nights_booked INT,
    total_amount DECIMAL(10,2),
    FOREIGN KEY (guest_id) REFERENCES guests(guest_id),
    FOREIGN KEY (hotel_id) REFERENCES hotels(hotel_id)
);

CREATE TABLE IF NOT EXISTS staff (
    staff_id VARCHAR(20) PRIMARY KEY,
    staff_name VARCHAR(100),
    hire_date DATE,
    rating DECIMAL(3,2),
    department VARCHAR(50),
    is_active INT
);

CREATE TABLE IF NOT EXISTS stays (
    stay_id VARCHAR(20) PRIMARY KEY,
    booking_id VARCHAR(20),
    room_id VARCHAR(20),
    staff_id VARCHAR(20),
    check_in_date DATE,
    check_out_date DATE,
    status VARCHAR(30),
    nights_stayed INT,
    service_requests INT,
    stay_duration_hrs DECIMAL(10,2),
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
    FOREIGN KEY (room_id) REFERENCES rooms(room_id),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);

-- Expected imported row counts:
-- guests 350, hotels 25, rooms 600, bookings 2800, stays 3200, staff 70

SELECT 'guests' AS table_name, COUNT(*) AS row_count FROM guests
UNION ALL SELECT 'hotels', COUNT(*) FROM hotels
UNION ALL SELECT 'rooms', COUNT(*) FROM rooms
UNION ALL SELECT 'bookings', COUNT(*) FROM bookings
UNION ALL SELECT 'stays', COUNT(*) FROM stays
UNION ALL SELECT 'staff', COUNT(*) FROM staff;

-- ==================== SPRINT 3: BASIC ANALYSIS ====================

-- 1. What is the total number of guests?
SELECT COUNT(*) AS total_guests FROM guests;

-- 2. What is the total number of bookings?
SELECT COUNT(*) AS total_bookings FROM bookings;

-- 3. What is the total number of stays?
SELECT COUNT(*) AS total_stays FROM stays;

-- 4. What are the different room types available?
SELECT DISTINCT room_type FROM rooms ORDER BY room_type;

-- 5. How many staff members are currently active?
SELECT COUNT(*) AS active_staff FROM staff WHERE is_active = 1;

-- 6. What are the different booking channels?
SELECT DISTINCT booking_channel FROM bookings ORDER BY booking_channel;

-- 7. What is the total booking amount across all bookings?
SELECT SUM(total_amount) AS total_booking_amount FROM bookings;

-- 8. What is the average nights booked per booking?
SELECT AVG(nights_booked) AS average_nights_booked FROM bookings;

-- ==================== SPRINT 4.1: UNDERSTAND BOOKING DEMAND ====================

-- Compare the number of bookings across hotels.
SELECT b.hotel_id, h.hotel_name, COUNT(b.booking_id) AS total_bookings
FROM bookings b JOIN hotels h ON b.hotel_id = h.hotel_id
GROUP BY b.hotel_id, h.hotel_name
ORDER BY total_bookings DESC;

-- Compare bookings across different booking channels.
SELECT booking_channel, COUNT(*) AS total_bookings
FROM bookings GROUP BY booking_channel
ORDER BY total_bookings DESC;

-- Compare bookings based on room type requested.
SELECT room_type_requested, COUNT(*) AS total_bookings
FROM bookings GROUP BY room_type_requested
ORDER BY total_bookings DESC;

-- Examine how booking volume changes over time.
SELECT YEAR(booking_date) AS booking_year, MONTH(booking_date) AS booking_month,
       COUNT(*) AS total_bookings
FROM bookings
GROUP BY YEAR(booking_date), MONTH(booking_date)
ORDER BY booking_year, booking_month;

-- Look at the booking amount across different groups.
SELECT h.hotel_id, h.hotel_name, b.booking_channel,
       COUNT(b.booking_id) AS total_bookings,
       SUM(b.total_amount) AS total_booking_amount
FROM bookings b JOIN hotels h ON b.hotel_id = h.hotel_id
GROUP BY h.hotel_id, h.hotel_name, b.booking_channel
ORDER BY total_booking_amount DESC;

-- ==================== SPRINT 4.2: UNDERSTAND GUEST BOOKING BEHAVIOUR ====================

-- Compare guests based on the number of bookings they make.
SELECT g.guest_id, g.guest_name, COUNT(b.booking_id) AS total_bookings
FROM guests g JOIN bookings b ON g.guest_id = b.guest_id
GROUP BY g.guest_id, g.guest_name
ORDER BY total_bookings DESC;

-- Identify guests with a higher total booking amount.
SELECT g.guest_id, g.guest_name, SUM(b.total_amount) AS total_booking_amount
FROM guests g JOIN bookings b ON g.guest_id = b.guest_id
GROUP BY g.guest_id, g.guest_name
ORDER BY total_booking_amount DESC;

-- Compare guest activity across hotels.
SELECT b.hotel_id, h.hotel_name,
       COUNT(DISTINCT b.guest_id) AS unique_guests,
       COUNT(b.booking_id) AS total_bookings
FROM bookings b JOIN hotels h ON b.hotel_id = h.hotel_id
GROUP BY b.hotel_id, h.hotel_name
ORDER BY total_bookings DESC;

-- Look at differences between Individual and Corporate guests.
SELECT g.guest_type, COUNT(b.booking_id) AS total_bookings,
       COUNT(DISTINCT g.guest_id) AS unique_guests,
       SUM(b.total_amount) AS total_booking_amount,
       AVG(b.total_amount) AS average_booking_amount
FROM guests g JOIN bookings b ON g.guest_id = b.guest_id
GROUP BY g.guest_type
ORDER BY total_booking_amount DESC;

-- Examine guest booking patterns over time.
SELECT YEAR(b.booking_date) AS booking_year, MONTH(b.booking_date) AS booking_month,
       g.guest_type, COUNT(b.booking_id) AS total_bookings
FROM bookings b JOIN guests g ON b.guest_id = g.guest_id
GROUP BY YEAR(b.booking_date), MONTH(b.booking_date), g.guest_type
ORDER BY booking_year, booking_month, g.guest_type;

-- ==================== SPRINT 4.3: EVALUATE STAY PERFORMANCE ====================

-- Compare stay outcomes across different hotels.
SELECT b.hotel_id, h.hotel_name, s.status, COUNT(s.stay_id) AS total_stays
FROM bookings b JOIN hotels h ON b.hotel_id = h.hotel_id
JOIN stays s ON b.booking_id = s.booking_id
GROUP BY b.hotel_id, h.hotel_name, s.status
ORDER BY h.hotel_name, total_stays DESC;

-- Examine stay duration.
SELECT AVG(stay_duration_hrs) AS average_stay_duration_hours,
       AVG(nights_stayed) AS average_nights_stayed
FROM stays;

-- Compare stay outcomes by status.
SELECT status, COUNT(*) AS total_stays,
       AVG(stay_duration_hrs) AS average_stay_duration_hours,
       AVG(nights_stayed) AS average_nights_stayed
FROM stays
GROUP BY status
ORDER BY total_stays DESC;

-- Identify hotels with higher booking activity or poorer outcomes.
SELECT b.hotel_id, h.hotel_name,
       COUNT(DISTINCT b.booking_id) AS total_bookings,
       SUM(CASE WHEN s.status IN ('No-show','Cancelled') THEN 1 ELSE 0 END) AS problem_stays
FROM bookings b JOIN hotels h ON b.hotel_id = h.hotel_id
JOIN stays s ON b.booking_id = s.booking_id
GROUP BY b.hotel_id, h.hotel_name
ORDER BY problem_stays DESC, total_bookings DESC;

-- Compare stay performance over time.
SELECT YEAR(s.check_in_date) AS stay_year, MONTH(s.check_in_date) AS stay_month,
       s.status, COUNT(*) AS total_stays
FROM stays s
GROUP BY YEAR(s.check_in_date), MONTH(s.check_in_date), s.status
ORDER BY stay_year, stay_month, s.status;

-- ==================== SPRINT 4.4: UNDERSTAND STAFF AND ROOM PERFORMANCE ====================

-- Compare the number of stays handled by staff members.
SELECT st.staff_id, st.staff_name, COUNT(s.stay_id) AS total_stays_handled
FROM staff st JOIN stays s ON st.staff_id = s.staff_id
GROUP BY st.staff_id, st.staff_name
ORDER BY total_stays_handled DESC;

-- Compare staff performance across stay outcomes.
SELECT st.staff_id, st.staff_name, s.status, COUNT(s.stay_id) AS total_stays
FROM staff st JOIN stays s ON st.staff_id = s.staff_id
GROUP BY st.staff_id, st.staff_name, s.status
ORDER BY st.staff_name, total_stays DESC;

-- Examine stay duration across staff members.
SELECT st.staff_id, st.staff_name,
       AVG(s.stay_duration_hrs) AS average_stay_duration_hours,
       AVG(s.nights_stayed) AS average_nights_stayed
FROM staff st JOIN stays s ON st.staff_id = s.staff_id
GROUP BY st.staff_id, st.staff_name
ORDER BY average_stay_duration_hours DESC;

-- Compare room usage across different room types.
SELECT r.room_type, COUNT(s.stay_id) AS total_stays,
       COUNT(DISTINCT r.room_id) AS rooms_used
FROM rooms r JOIN stays s ON r.room_id = s.room_id
GROUP BY r.room_type
ORDER BY total_stays DESC;

-- Look at stay performance across different rooms.
SELECT r.room_id, r.room_type, COUNT(s.stay_id) AS total_stays,
       AVG(s.stay_duration_hrs) AS average_stay_duration_hours,
       SUM(s.service_requests) AS total_service_requests
FROM rooms r JOIN stays s ON r.room_id = s.room_id
GROUP BY r.room_id, r.room_type
ORDER BY total_stays DESC;

-- ==================== SPRINT 4.5: IDENTIFY BOOKING AND STAY PROBLEMS ====================

-- Examine which bookings resulted in cancellations or no-shows.
SELECT s.status, COUNT(*) AS problem_stays
FROM stays s
WHERE s.status IN ('Cancelled','No-show')
GROUP BY s.status
ORDER BY problem_stays DESC;

-- Identify common stay statuses and problem patterns.
SELECT status, COUNT(*) AS total_stays,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM stays), 2) AS percentage_of_stays
FROM stays
GROUP BY status
ORDER BY total_stays DESC;

-- Compare stay performance for bookings with high service request counts.
SELECT CASE WHEN service_requests >= 5 THEN 'High Service Requests'
            ELSE 'Low/Normal Service Requests' END AS service_request_group,
       status, COUNT(*) AS total_stays,
       AVG(stay_duration_hrs) AS average_stay_duration_hours
FROM stays
GROUP BY CASE WHEN service_requests >= 5 THEN 'High Service Requests'
              ELSE 'Low/Normal Service Requests' END, status
ORDER BY service_request_group, total_stays DESC;

-- Examine whether certain hotels experience more booking problems.
SELECT b.hotel_id, h.hotel_name, COUNT(*) AS problem_stays
FROM bookings b JOIN hotels h ON b.hotel_id = h.hotel_id
JOIN stays s ON b.booking_id = s.booking_id
WHERE s.status IN ('Cancelled','No-show')
GROUP BY b.hotel_id, h.hotel_name
ORDER BY problem_stays DESC;

-- ==================== END ====================
